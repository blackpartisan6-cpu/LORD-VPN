# LORD VPN (Android)
1. Ouvrir dans Android Studio (Koala+), laisser Gradle synchroniser.
2. Télécharger **libv2ray.aar** (projet AndroidLibXrayLite, release récente) et le placer dans `app/libs/`.
3. Run sur un appareil réel, accepter la permission VPN.

Fonctions : import liens / JSON V2Ray / base64 / fichiers / URL d'abonnement, ping TCP, génération de config Xray
(vmess, vless+reality, trojan, shadowsocks ; tcp, ws, grpc, httpupgrade), service VPN + TUN.

Note : XrayRunner appelle libv2ray par réflexion (initCoreEnv, newCoreController, startLoop(config, fd)).
Si votre version de l'AAR a une API différente, ajustez uniquement XrayRunner.kt.

## Build en ligne (sans PC)
Poussez ce dossier sur GitHub : l'onglet Actions compile l'APK et le fournit dans « Artifacts » (LordVPN-apk).
