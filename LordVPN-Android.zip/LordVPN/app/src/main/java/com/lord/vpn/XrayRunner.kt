package com.lord.vpn

import android.content.Context
import java.lang.reflect.Proxy

/** Lance libv2ray (AndroidLibXrayLite) par réflexion : l'app compile même sans l'AAR. */
class XrayRunner(private val ctx: Context) {
    private var ctrl: Any? = null

    fun start(config: String, fd: Int): String? = try {
        val lib = Class.forName("libv2ray.Libv2ray")
        lib.methods.first { it.name == "initCoreEnv" }.invoke(null, ctx.filesDir.absolutePath, "")
        val hCls = Class.forName("libv2ray.CoreCallbackHandler")
        val h = Proxy.newProxyInstance(hCls.classLoader, arrayOf(hCls)) { _, m, _ -> if (m.returnType == java.lang.Long.TYPE) 0L else null }
        ctrl = lib.methods.first { it.name == "newCoreController" }.invoke(null, h)
        val m = ctrl!!.javaClass.methods.first { it.name == "startLoop" }
        val args = m.parameterTypes.map { it }.let { p ->
            if (p.size == 1) arrayOf<Any>(config)
            else arrayOf(config, if (p[1] == java.lang.Long.TYPE) fd.toLong() else fd)
        }
        m.invoke(ctrl, *args); null
    } catch (e: ClassNotFoundException) {
        "Cœur absent : ajoutez libv2ray.aar dans app/libs"
    } catch (e: Exception) {
        "Erreur cœur : ${e.cause?.message ?: e.message}"
    }

    fun stop() {
        try { ctrl?.javaClass?.methods?.first { it.name == "stopLoop" }?.invoke(ctrl) } catch (_: Exception) {}
        ctrl = null
    }
}
