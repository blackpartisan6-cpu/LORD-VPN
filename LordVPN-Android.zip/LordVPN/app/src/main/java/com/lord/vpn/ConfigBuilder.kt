package com.lord.vpn

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** Transforme un lien/outbound en config Xray complète (SOCKS local + outbound "proxy"). */
object ConfigBuilder {
    private fun b64(s: String) = String(Base64.decode(s.replace('-', '+').replace('_', '/'), Base64.DEFAULT))

    private fun stream(net: String, sec: String, host: String, path: String, sni: String, q: Uri? = null): JSONObject {
        val s = JSONObject().put("network", net).put("security", sec)
        when (net) {
            "ws" -> s.put("wsSettings", JSONObject().put("path", path).put("headers", JSONObject().put("Host", host)))
            "grpc" -> s.put("grpcSettings", JSONObject().put("serviceName", path))
            "httpupgrade" -> s.put("httpupgradeSettings", JSONObject().put("path", path).put("host", host))
        }
        if (sec == "tls") s.put("tlsSettings", JSONObject().put("serverName", sni.ifEmpty { host }).put("allowInsecure", false))
        if (sec == "reality" && q != null) s.put("realitySettings", JSONObject()
            .put("serverName", sni).put("publicKey", q.getQueryParameter("pbk") ?: "")
            .put("shortId", q.getQueryParameter("sid") ?: "").put("fingerprint", q.getQueryParameter("fp") ?: "chrome"))
        return s
    }

    private fun outbound(raw: String): JSONObject {
        if (raw.trim().startsWith("{")) return JSONObject(raw).put("tag", "proxy")
        if (raw.startsWith("vmess://")) {
            val j = JSONObject(b64(raw.substring(8)))
            val net = j.optString("net", "tcp"); val tls = j.optString("tls")
            val user = JSONObject().put("id", j.getString("id")).put("alterId", j.optInt("aid", 0)).put("security", j.optString("scy", "auto"))
            return JSONObject().put("tag", "proxy").put("protocol", "vmess")
                .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                    .put("address", j.getString("add")).put("port", j.get("port").toString().toInt()).put("users", JSONArray().put(user)))))
                .put("streamSettings", stream(net, if (tls == "tls") "tls" else "none", j.optString("host"), j.optString("path", "/"), j.optString("sni")))
        }
        val u = Uri.parse(raw)
        val q = u
        val net = q.getQueryParameter("type") ?: "tcp"
        val sec = q.getQueryParameter("security") ?: "none"
        val st = stream(net, sec, q.getQueryParameter("host") ?: "", q.getQueryParameter("path") ?: q.getQueryParameter("serviceName") ?: "/", q.getQueryParameter("sni") ?: "", q)
        return when (u.scheme?.lowercase()) {
            "vless" -> JSONObject().put("tag", "proxy").put("protocol", "vless").put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                .put("address", u.host).put("port", u.port).put("users", JSONArray().put(JSONObject()
                    .put("id", u.userInfo).put("encryption", "none").put("flow", q.getQueryParameter("flow") ?: "")))))).put("streamSettings", st)
            "trojan" -> JSONObject().put("tag", "proxy").put("protocol", "trojan").put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                .put("address", u.host).put("port", u.port).put("password", u.userInfo)))).put("streamSettings", if (sec == "none") stream(net, "tls", "", "/", q.getQueryParameter("sni") ?: "") else st)
            "ss" -> {
                var host = u.host; var port = u.port; var ui = u.userInfo ?: ""
                if (host.isNullOrEmpty()) { val d = b64(raw.removePrefix("ss://").substringBefore('#')); ui = d.substringBeforeLast('@'); val hp = d.substringAfterLast('@'); host = hp.substringBeforeLast(':'); port = hp.substringAfterLast(':').toInt() }
                else if (!ui.contains(':')) ui = b64(ui)
                JSONObject().put("tag", "proxy").put("protocol", "shadowsocks").put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                    .put("address", host).put("port", port).put("method", ui.substringBefore(':')).put("password", ui.substringAfter(':')))))
            }
            else -> throw IllegalArgumentException("Protocole non supporté")
        }
    }

    fun build(raw: String): String = JSONObject()
        .put("log", JSONObject().put("loglevel", "warning"))
        .put("dns", JSONObject().put("servers", JSONArray().put("1.1.1.1").put("8.8.8.8")))
        .put("inbounds", JSONArray().put(JSONObject().put("tag", "socks").put("port", 10808).put("listen", "127.0.0.1").put("protocol", "socks")
            .put("settings", JSONObject().put("udp", true)).put("sniffing", JSONObject().put("enabled", true).put("destOverride", JSONArray().put("http").put("tls")))))
        .put("outbounds", JSONArray().put(outbound(raw)).put(JSONObject().put("tag", "direct").put("protocol", "freedom")))
        .toString()
}
