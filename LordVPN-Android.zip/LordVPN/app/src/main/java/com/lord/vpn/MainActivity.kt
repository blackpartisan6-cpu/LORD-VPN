package com.lord.vpn

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private val Gold = Color(0xFFD4A937)
private val Bg = Color(0xFF0B0B10)
private val Card = Color(0xFF16161F)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("lord", Context.MODE_PRIVATE) }

    private fun load(): List<Server> {
        val a = JSONArray(prefs.getString("servers", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it)
            Server(o.getString("id"), o.getString("name"), o.getString("type"), o.getString("host"), o.getInt("port"), o.getString("raw")) }
    }
    private fun save(l: List<Server>) = prefs.edit().putString("servers", JSONArray(l.map {
        JSONObject().put("id", it.id).put("name", it.name).put("type", it.type).put("host", it.host).put("port", it.port).put("raw", it.raw) }).toString()).apply()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Card)) { App() } }
    }

    @Composable
    fun App() {
        var servers by remember { mutableStateOf(load()) }
        var sel by remember { mutableStateOf(servers.firstOrNull()?.id) }
        var on by remember { mutableStateOf(false) }
        var text by remember { mutableStateOf("") }
        var msg by remember { mutableStateOf("") }
        var sub by remember { mutableStateOf("") }
        val ping = remember { mutableStateMapOf<String, String>() }

        fun add(t: String) {
            val new = ServerParser.parse(t).filter { n -> servers.none { it.raw == n.raw } }
            servers = servers + new; save(servers)
            if (sel == null) sel = servers.firstOrNull()?.id
            msg = if (new.isEmpty()) "Aucune config valide" else "${new.size} serveur(s) ajouté(s)"
        }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
            u?.let { add(contentResolver.openInputStream(it)!!.bufferedReader().readText()) }
        }
        fun go() {
            val c = servers.find { it.id == sel } ?: return
            startService(Intent(this, LordVpnService::class.java).putExtra("raw", c.raw)); on = true
        }
        val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { if (it.resultCode == Activity.RESULT_OK) go() }

        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(16.dp)) {
            Text("LORD VPN", color = Gold, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth(), Alignment.Center) {
                Button(onClick = {
                    if (on) { startService(Intent(this@MainActivity, LordVpnService::class.java).setAction("STOP")); on = false }
                    else VpnService.prepare(this@MainActivity)?.let { perm.launch(it) } ?: go()
                }, modifier = Modifier.size(130.dp), shape = androidx.compose.foundation.shape.CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = if (on) Color(0xFF3ECF8E) else Card, contentColor = if (on) Color.White else Gold)) {
                    Text(if (on) "CONNECTÉ" else "CONNECTER")
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = { Text("vmess:// vless:// trojan:// ss:// …") }, maxLines = 3)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ add(text); text = "" }) { Text("Ajouter") }
                OutlinedButton({ picker.launch("*/*") }) { Text("Fichier") }
                OutlinedButton({ servers.forEach { s -> ping[s.id] = "…"; Net.ping(s.host, s.port) { ms -> runOnUiThread { ping[s.id] = ms } } } }) { Text("Ping") }
            }
            OutlinedTextField(sub, { sub = it }, Modifier.fillMaxWidth().padding(top = 8.dp), placeholder = { Text("URL d’abonnement https://…") }, singleLine = true)
            Button({ msg = "Téléchargement…"; Net.fetch(sub.trim()) { r -> runOnUiThread { if (r == null) msg = "Échec du téléchargement" else add(r) } } }) { Text("Importer l’URL") }
            Text(msg, color = Color.Gray)
            LazyColumn {
                items(servers, key = { it.id }) { s ->
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp).background(Card).clickable { if (!on) sel = s.id }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, color = if (s.id == sel) Gold else Color.White)
                            Text("${s.type.uppercase()} · ${s.host}:${s.port} ${ping[s.id] ?: ""}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton({ servers = servers - s; save(servers); if (sel == s.id) sel = servers.firstOrNull()?.id }) { Text("✕") }
                    }
                }
            }
        }
    }
}
