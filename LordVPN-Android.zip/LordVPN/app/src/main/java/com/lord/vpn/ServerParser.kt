package com.lord.vpn

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

data class Server(val id: String, val name: String, val type: String, val host: String, val port: Int, val raw: String)

object ServerParser {
    private fun b64(s: String): String {
        val t = s.replace('-', '+').replace('_', '/')
        return String(Base64.decode(t, Base64.DEFAULT))
    }

    fun parseLink(line: String): Server? = try {
        val l = line.trim()
        if (l.startsWith("vmess://")) {
            val j = JSONObject(b64(l.substring(8)))
            Server(l.hashCode().toString(), j.optString("ps", j.getString("add")), "vmess", j.getString("add"), j.get("port").toString().toInt(), l)
        } else {
            val m = Regex("^(vless|trojan|ss)://(.+)$", RegexOption.IGNORE_CASE).find(l)
            if (m == null) null else {
                val type = m.groupValues[1].lowercase()
                var body = m.groupValues[2]
                var name = ""
                body.indexOf('#').let { if (it >= 0) { name = URLDecoder.decode(body.substring(it + 1), "UTF-8"); body = body.substring(0, it) } }
                body = body.substringBefore('?')
                if (!body.contains('@')) body = b64(body)
                val hp = Regex("^\\[?([^\\]]+?)\\]?:(\\d+)").find(body.substringAfterLast('@')) ?: return null
                Server(l.hashCode().toString(), name.ifEmpty { hp.groupValues[1] }, if (type == "ss") "shadowsocks" else type, hp.groupValues[1], hp.groupValues[2].toInt(), l)
            }
        }
    } catch (e: Exception) { null }

    private fun parseJson(t: String): List<Server> = try {
        val j = JSONObject(t)
        val arr: JSONArray = j.optJSONArray("outbounds") ?: JSONArray()
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val p = o.optString("protocol")
            val s = o.optJSONObject("settings") ?: return@mapNotNull null
            val n = (s.optJSONArray("vnext") ?: s.optJSONArray("servers"))?.optJSONObject(0) ?: return@mapNotNull null
            if (p !in listOf("vmess", "vless", "trojan", "shadowsocks")) null
            else Server(o.toString().hashCode().toString(), o.optString("tag", n.getString("address")), p, n.getString("address"), n.getInt("port"), o.toString())
        }
    } catch (e: Exception) { emptyList() }

    /** Accepte : liens, JSON V2Ray, abonnement base64. */
    fun parse(text: String): List<Server> {
        val js = parseJson(text.trim())
        if (js.isNotEmpty()) return js
        var lines = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (lines.size == 1 && !lines[0].contains("://")) {
            lines = try { b64(lines[0]).trim().split(Regex("\\s+")) } catch (e: Exception) { lines }
        }
        return lines.mapNotNull { parseLink(it) }
    }
}
