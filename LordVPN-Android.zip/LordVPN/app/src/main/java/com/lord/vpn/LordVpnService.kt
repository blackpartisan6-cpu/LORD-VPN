package com.lord.vpn

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.widget.Toast

class LordVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var runner: XrayRunner? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stop(); return START_NOT_STICKY }
        val raw = intent?.getStringExtra("raw") ?: return START_NOT_STICKY
        startForeground(1, notif())
        start(raw)
        return START_STICKY
    }

    private fun notif(): Notification {
        val ch = "lord"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "LORD VPN", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, ch).setContentTitle("LORD VPN connecté")
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
    }

    private fun toast(s: String) = Handler(Looper.getMainLooper()).post { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun start(raw: String) {
        val cfg = try { ConfigBuilder.build(raw) } catch (e: Exception) { toast("Config invalide : ${e.message}"); stop(); return }
        tun = Builder().setSession("LORD VPN").setMtu(1500)
            .addAddress("10.10.14.1", 30).addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1").addDisallowedApplication(packageName).establish()
        val fd = tun?.fd ?: run { toast("Impossible d'ouvrir le TUN"); stop(); return }
        runner = XrayRunner(this)
        runner!!.start(cfg, fd)?.let { toast(it); stop() }
    }

    private fun stop() {
        runner?.stop(); runner = null
        tun?.close(); tun = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onDestroy() { stop(); super.onDestroy() }
}
