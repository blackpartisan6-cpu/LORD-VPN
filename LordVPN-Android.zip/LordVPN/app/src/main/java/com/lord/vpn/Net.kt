package com.lord.vpn

import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

object Net {
    /** Latence TCP en ms (ou "timeout"). */
    fun ping(host: String, port: Int, cb: (String) -> Unit) = Thread {
        val t = System.nanoTime()
        val r = try { Socket().use { it.connect(InetSocketAddress(host, port), 3000) }; "${(System.nanoTime() - t) / 1_000_000} ms" } catch (e: Exception) { "timeout" }
        cb(r)
    }.start()

    /** Télécharge un abonnement (URL). */
    fun fetch(url: String, cb: (String?) -> Unit) = Thread {
        val r = try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000; c.setRequestProperty("User-Agent", "LordVPN/1.0")
            c.inputStream.bufferedReader().readText()
        } catch (e: Exception) { null }
        cb(r)
    }.start()
}
